package br.com.fundatec.model;

public enum Tipo {

CONTA_CORRENTE,POUPANCA}
